// ── LiveSub Content Script ───────────────────────────────────────────────────
// Injected into every page. Creates a floating subtitle overlay,
// manages Web Speech API recognition, handles dragging.

(function() {
  if (window.__liveSubInitialized) return;
  window.__liveSubInitialized = true;

  // ── State ──────────────────────────────────────────────────────────────────
  let recognition = null;
  let isRunning   = false;
  let overlay     = null;
  let textEl      = null;
  let settings    = {};
  let dragState   = null;
  let restartTimer = null;
  let finalBuffer  = '';
  let interimText  = '';

  // ── Load saved settings ────────────────────────────────────────────────────
  const DEFAULTS = {
    enabled: false,
    fontSize: 22,
    textColor: '#ffffff',
    bgStyle: 'none',
    position: 'bot-left',
    lang: 'en-US',
    posX: null,
    posY: null,
  };

  chrome.storage.local.get(DEFAULTS, (saved) => {
    settings = { ...DEFAULTS, ...saved };
    if (settings.enabled) {
      createOverlay();
      startRecognition();
    }
  });

  // ── Message listener ───────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'START') {
      settings = { ...settings, ...msg.settings };
      createOverlay();
      startRecognition();
    } else if (msg.type === 'STOP') {
      stopRecognition();
      removeOverlay();
    } else if (msg.type === 'RESTART') {
      settings = { ...settings, ...msg.settings };
      stopRecognition();
      setTimeout(() => startRecognition(), 300);
    } else if (msg.type === 'UPDATE_SETTINGS') {
      settings = { ...settings, ...msg.settings };
      applySettings();
    } else if (msg.type === 'CLEAR') {
      finalBuffer = '';
      interimText = '';
      if (textEl) textEl.innerHTML = '';
    }
    sendResponse({ ok: true });
    return true;
  });

  // ── Overlay creation ───────────────────────────────────────────────────────
  function createOverlay() {
    if (overlay) { applySettings(); return; }

    overlay = document.createElement('div');
    overlay.id = '__livesub_overlay__';

    textEl = document.createElement('div');
    textEl.id = '__livesub_text__';

    const handle = document.createElement('div');
    handle.id = '__livesub_handle__';
    handle.title = 'Drag to move';

    const closeBtn = document.createElement('div');
    closeBtn.id = '__livesub_close__';
    closeBtn.textContent = '×';
    closeBtn.title = 'Close subtitles';
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      stopRecognition();
      removeOverlay();
      chrome.storage.local.set({ enabled: false });
    });

    overlay.appendChild(handle);
    overlay.appendChild(closeBtn);
    overlay.appendChild(textEl);
    document.body.appendChild(overlay);

    applySettings();
    snapToPosition(settings.position);
    enableDrag(overlay, handle);
  }

  function removeOverlay() {
    if (overlay) {
      overlay.remove();
      overlay = null;
      textEl = null;
    }
  }

  // ── Apply visual settings ──────────────────────────────────────────────────
  function applySettings() {
    if (!overlay || !textEl) return;

    // font size
    textEl.style.fontSize = settings.fontSize + 'px';
    textEl.style.lineHeight = (settings.fontSize * 1.35) + 'px';

    // text color
    textEl.style.color = settings.textColor;

    // background style
    overlay.setAttribute('data-bg', settings.bgStyle);
    switch (settings.bgStyle) {
      case 'none':
        overlay.style.background = 'transparent';
        overlay.style.backdropFilter = 'none';
        overlay.style.webkitBackdropFilter = 'none';
        overlay.style.borderRadius = '0';
        overlay.style.padding = '0';
        break;
      case 'dark':
        overlay.style.background = 'rgba(0,0,0,0.72)';
        overlay.style.backdropFilter = 'none';
        overlay.style.webkitBackdropFilter = 'none';
        overlay.style.borderRadius = '10px';
        overlay.style.padding = '10px 16px';
        break;
      case 'blur':
        overlay.style.background = 'rgba(0,0,0,0.35)';
        overlay.style.backdropFilter = 'blur(12px) saturate(1.4)';
        overlay.style.webkitBackdropFilter = 'blur(12px) saturate(1.4)';
        overlay.style.borderRadius = '12px';
        overlay.style.padding = '10px 16px';
        break;
      case 'shadow':
        overlay.style.background = 'transparent';
        overlay.style.backdropFilter = 'none';
        overlay.style.webkitBackdropFilter = 'none';
        overlay.style.borderRadius = '0';
        overlay.style.padding = '4px 0';
        textEl.style.textShadow = `
          2px 2px 6px rgba(0,0,0,0.95),
          -1px -1px 4px rgba(0,0,0,0.9),
          0 0 12px rgba(0,0,0,0.8)
        `;
        break;
    }
    if (settings.bgStyle !== 'shadow') {
      textEl.style.textShadow = '1px 1px 4px rgba(0,0,0,0.8)';
    }

    // snap if position changed and no custom drag position
    if (settings.posX === null || settings.posY === null) {
      snapToPosition(settings.position);
    }
  }

  // ── Position snapping ──────────────────────────────────────────────────────
  function snapToPosition(pos) {
    if (!overlay) return;
    const W = window.innerWidth;
    const H = window.innerHeight;
    const OW = Math.min(overlay.offsetWidth || 480, W - 40);
    const OH = overlay.offsetHeight || 80;
    const pad = 24;

    let x, y;
    const col = pos.split('-')[1]; // left / center / right
    const row = pos.split('-')[0]; // top / mid / bot

    switch (col) {
      case 'left':   x = pad; break;
      case 'center': x = (W - OW) / 2; break;
      case 'right':  x = W - OW - pad; break;
      default:       x = pad;
    }
    switch (row) {
      case 'top': y = pad; break;
      case 'mid': y = (H - OH) / 2; break;
      case 'bot': y = H - OH - pad; break;
      default:    y = H - OH - pad;
    }

    overlay.style.left = Math.max(0, x) + 'px';
    overlay.style.top  = Math.max(0, y) + 'px';
  }

  // ── Drag ──────────────────────────────────────────────────────────────────
  function enableDrag(el, handle) {
    handle.addEventListener('mousedown', onMouseDown);
    handle.addEventListener('touchstart', onTouchStart, { passive: false });

    function onMouseDown(e) {
      e.preventDefault();
      startDrag(e.clientX, e.clientY);
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    }
    function onMouseMove(e) { doDrag(e.clientX, e.clientY); }
    function onMouseUp()    { endDrag(); document.removeEventListener('mousemove', onMouseMove); document.removeEventListener('mouseup', onMouseUp); }

    function onTouchStart(e) {
      e.preventDefault();
      const t = e.touches[0];
      startDrag(t.clientX, t.clientY);
      document.addEventListener('touchmove', onTouchMove, { passive: false });
      document.addEventListener('touchend', onTouchEnd);
    }
    function onTouchMove(e) { e.preventDefault(); doDrag(e.touches[0].clientX, e.touches[0].clientY); }
    function onTouchEnd()   { endDrag(); document.removeEventListener('touchmove', onTouchMove); document.removeEventListener('touchend', onTouchEnd); }

    function startDrag(cx, cy) {
      const rect = el.getBoundingClientRect();
      dragState = { ox: cx - rect.left, oy: cy - rect.top };
      el.style.transition = 'none';
    }
    function doDrag(cx, cy) {
      if (!dragState || !overlay) return;
      const x = Math.max(0, Math.min(window.innerWidth  - overlay.offsetWidth,  cx - dragState.ox));
      const y = Math.max(0, Math.min(window.innerHeight - overlay.offsetHeight, cy - dragState.oy));
      overlay.style.left = x + 'px';
      overlay.style.top  = y + 'px';
    }
    function endDrag() {
      if (!overlay) return;
      dragState = null;
      const x = parseFloat(overlay.style.left);
      const y = parseFloat(overlay.style.top);
      // save custom position
      chrome.storage.local.set({ posX: x, posY: y });
    }
  }

  // ── Web Speech API ─────────────────────────────────────────────────────────
  function startRecognition() {
    if (isRunning) return;
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      showError('Speech API not supported in this browser. Use Chrome.');
      return;
    }

    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SR();
    recognition.continuous    = true;
    recognition.interimResults = true;
    recognition.lang          = settings.lang || 'en-US';
    recognition.maxAlternatives = 1;

    recognition.onstart = () => { isRunning = true; };

    recognition.onresult = (event) => {
      let interim = '';
      let newFinal = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        if (res.isFinal) {
          newFinal += res[0].transcript + ' ';
        } else {
          interim += res[0].transcript;
        }
      }

      if (newFinal) {
        finalBuffer += newFinal;
        // Keep only last ~200 chars of final to avoid overflow
        if (finalBuffer.length > 200) {
          finalBuffer = finalBuffer.slice(finalBuffer.length - 200);
        }
      }
      interimText = interim;
      renderText();
    };

    recognition.onerror = (e) => {
      if (e.error === 'no-speech') return; // expected, just restart
      if (e.error === 'not-allowed') {
        showError('Mic blocked — allow mic in browser settings');
        return;
      }
    };

    recognition.onend = () => {
      isRunning = false;
      // auto-restart unless manually stopped
      if (settings.enabled && overlay) {
        restartTimer = setTimeout(() => startRecognition(), 300);
      }
    };

    recognition.start();
  }

  function stopRecognition() {
    settings.enabled = false;
    clearTimeout(restartTimer);
    isRunning = false;
    if (recognition) {
      try { recognition.stop(); } catch(e) {}
      recognition = null;
    }
    finalBuffer = '';
    interimText = '';
  }

  // ── Render text ────────────────────────────────────────────────────────────
  function renderText() {
    if (!textEl) return;
    // Show last ~120 chars of final + current interim in italic
    const displayFinal = finalBuffer.slice(-120);
    textEl.innerHTML =
      `<span class="__ls_final__">${escHtml(displayFinal)}</span>` +
      (interimText ? `<span class="__ls_interim__">${escHtml(interimText)}</span>` : '');
  }

  function showError(msg) {
    if (!textEl) return;
    textEl.innerHTML = `<span style="color:#ff4f6a;font-size:13px;">[${msg}]</span>`;
  }

  function escHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

})();
