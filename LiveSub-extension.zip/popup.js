// ── Default settings ─────────────────────────────────────────────────────────
const DEFAULTS = {
  enabled: false,
  fontSize: 22,
  textColor: '#ffffff',
  bgStyle: 'none',
  position: 'bot-left',
  lang: 'en-US',
  posX: null,
  posY: null,
};

let settings = { ...DEFAULTS };

// ── Load settings from storage ───────────────────────────────────────────────
chrome.storage.local.get(DEFAULTS, (saved) => {
  settings = { ...DEFAULTS, ...saved };
  applyToUI();
});

function applyToUI() {
  // toggle
  const tog = document.getElementById('main-toggle');
  tog.checked = settings.enabled;
  updateToggleLabel(settings.enabled);

  // font size
  document.getElementById('font-size').value = settings.fontSize;
  document.getElementById('size-val').textContent = settings.fontSize + 'px';

  // color swatches
  document.querySelectorAll('.color-swatch').forEach(sw => {
    sw.classList.toggle('selected', sw.dataset.color === settings.textColor);
  });

  // bg buttons
  document.querySelectorAll('.bg-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.bg === settings.bgStyle);
  });

  // position buttons
  document.querySelectorAll('.pos-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.pos === settings.position);
  });

  // lang
  document.getElementById('lang-select').value = settings.lang;

  // status
  updateStatus(settings.enabled);
}

function save(patch) {
  settings = { ...settings, ...patch };
  chrome.storage.local.set(settings);
  sendToContent({ type: 'UPDATE_SETTINGS', settings });
}

function updateToggleLabel(on) {
  const lbl = document.getElementById('toggle-label');
  lbl.textContent = on ? 'ON' : 'OFF';
  lbl.className = 'toggle-label' + (on ? ' on' : '');
}

function updateStatus(on, error) {
  const dot  = document.getElementById('status-dot');
  const text = document.getElementById('status-text');
  if (error) {
    dot.className = 'status-dot error';
    text.className = 'active error';
    text.textContent = error;
    return;
  }
  if (on) {
    dot.className = 'status-dot active';
    text.className = 'active';
    text.textContent = 'Listening… speak now';
  } else {
    dot.className = 'status-dot';
    text.className = '';
    text.textContent = 'Subtitles off';
  }
}

// ── Send message to active tab content script ────────────────────────────────
function sendToContent(msg) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, msg, (resp) => {
        if (chrome.runtime.lastError) {
          // content script might not be ready — inject it
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            files: ['content.js']
          }).then(() => {
            chrome.tabs.sendMessage(tabs[0].id, msg);
          }).catch(() => {});
        }
      });
    }
  });
}

// ── Toggle ───────────────────────────────────────────────────────────────────
document.getElementById('main-toggle').addEventListener('change', function() {
  const on = this.checked;
  updateToggleLabel(on);
  updateStatus(on);
  save({ enabled: on });
  sendToContent({ type: on ? 'START' : 'STOP', settings });
});

// ── Font size ────────────────────────────────────────────────────────────────
document.getElementById('font-size').addEventListener('input', function() {
  document.getElementById('size-val').textContent = this.value + 'px';
  save({ fontSize: parseInt(this.value) });
});

// ── Color swatches ───────────────────────────────────────────────────────────
document.getElementById('color-grid').addEventListener('click', (e) => {
  const sw = e.target.closest('.color-swatch');
  if (!sw) return;
  document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('selected'));
  sw.classList.add('selected');
  save({ textColor: sw.dataset.color });
});

// ── BG style ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.bg-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.bg-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    save({ bgStyle: btn.dataset.bg });
  });
});

// ── Position snap ────────────────────────────────────────────────────────────
document.querySelectorAll('.pos-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.pos-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    save({ position: btn.dataset.pos, posX: null, posY: null });
  });
});

// ── Language ─────────────────────────────────────────────────────────────────
document.getElementById('lang-select').addEventListener('change', function() {
  save({ lang: this.value });
  // restart if running
  if (settings.enabled) {
    sendToContent({ type: 'RESTART', settings });
  }
});

// ── Reset / Stop ─────────────────────────────────────────────────────────────
document.getElementById('btn-reset').addEventListener('click', () => {
  document.getElementById('main-toggle').checked = false;
  updateToggleLabel(false);
  updateStatus(false);
  save({ enabled: false });
  sendToContent({ type: 'STOP' });
  sendToContent({ type: 'CLEAR' });
});
