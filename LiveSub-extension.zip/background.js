// LiveSub background service worker
// Handles tab updates — re-inject content script if needed

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) return;

  chrome.storage.local.get({ enabled: false }, (data) => {
    if (!data.enabled) return;
    // Re-inject content script on page reload
    chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    }).catch(() => {});
    chrome.scripting.insertCSS({
      target: { tabId },
      files: ['content.css']
    }).catch(() => {});
  });
});
